<?php

namespace App\Http\Controllers;

use Illuminate\Routing\Controller as BaseController;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Auth;
use Response;
use App\DiaryUsers;
use App\DiaryLoginSessions;
use Hash;
use Str;

class ApiController extends BaseController
{
    //use AuthorizesRequests, DispatchesJobs, ValidatesRequests;
	
	public function __construct(Request $header_request){
       
        $this->device_type      = strtoupper($header_request->header('device-type'));
        $this->device_token     = $header_request->header('device-token');
        $this->header_api_token = $header_request->header('api-token');
    }    
	
	/*****fn to signup*****/
	public function registerApi(Request $request){
		
		if( $this->device_type =='' || $this->device_token=='' || $this->header_api_token =='' ){
            return Response::json(['success' => '0','message'=>'Insufficient data in headers'],200);
        }
		
		$first_name = ((isset($request->first_name)) ? ($request->first_name) : '');
		
		if($first_name == ""){
			return Response::json(['success'=>'0','message'=>'Please provide a first name.'],200);
            exit;
		}
		
		$last_name = ((isset($request->last_name)) ? ($request->last_name) : '');
		
		if($last_name == ""){
			return Response::json(['success'=>'0','message'=>'Please provide a last name.'],200);
            exit;
		}
		
		$email = ((isset($request->email)) ? ($request->email) : '');
		
		if($email == ""){
			return Response::json(['success'=>'0','message'=>'Please provide an email.'],200);
            exit;
		}
		
		$password = ((isset($request->password)) ? ($request->password) : '');
		
		if($password == ""){
			return Response::json(['success'=>'0','message'=>'Please provide a password.'],200);
            exit;
		}
		
		$phone_number = ((isset($request->phone_number)) ? ($request->phone_number) : '');
		
		if($phone_number == ""){
			return Response::json(['success'=>'0','message'=>'Please provide a phone number.'],200);
            exit;
		}
		
		//validations
		$userData = array('email' =>  $request->email,'password'  =>  $request->password, 'phone_number'=> $request->phone_number);
        $rules = array('email' =>'required|email|unique:diary_users','password'  =>'required|min:6',  'phone_number' => 'required|regex:/^([0-9\s\-\+\(\)]*)$/|min:10');
        $validator = Validator::make($userData,$rules);
		
		#if validation error 
        if($validator->fails()){
            $main_errors = $validator->getMessageBag()->toArray();
 
            $errors = array();
            foreach($main_errors as $key=>$value)
            {
                if($key == "password")
                {
                    $main_errors[$key][0] = $value;
                }
                if($key == "email")
                {
                    $main_errors[$key][0] = $value;
                }
				if($key == "phone_number")
                {
                    $main_errors[$key][0] = $value;
                }
                
                return Response::json([
                    'success' => '0',
                    'message' => $value[0]
                ],200);
            }
        }#if no validation error then save the user
        else{
            #inset into the table
 
			try{
 
                $id = DiaryUsers::insertGetId([
                    'first_name' =>$request->first_name,     
					'last_name' =>$request->last_name, 					
                    'email'=>$request->email,
                    'password'=>Hash::make($request->password),
                    'phone_number'=>$request->phone_number,
                ]);
            }catch(\Exception $e){
                return Response::json(['success' => '0','message'=>$e->getMessage()],200);
            }
 
            #json final response
            return Response::json(['success'=>'1','message'=>'Register Successfully.','user_id'=>(string)$id],200);
            exit;
            
        }
	}#end register function
	
	/*******login fn starts here*********/
	public function loginApi(Request $request){
		
		if( $this->device_type =='' || $this->device_token=='' || $this->header_api_token =='' ){
            return Response::json(['success' => '0','message'=>'Insufficient data in headers'],200);
        }
		
		$email = ((isset($request->email)) ? ($request->email) : '');
		
		if($email == ""){
			return Response::json(['success'=>'0','message'=>'Please provide an email.'],200);
            exit;
		}
		
		$password = ((isset($request->password)) ? ($request->password) : '');
		
		if($password == ""){
			return Response::json(['success'=>'0','message'=>'Please provide a password.'],200);
            exit;
		}
		
		
		##validation
        $userData = array('email' =>  $request->email,'password'  =>  $request->password);
        $rules = array('email' =>'required|email','password'  =>'required|min:6');
        $validator = Validator::make($userData,$rules);
		
		#if validation error 
        if($validator->fails()){
            $main_errors = $validator->getMessageBag()->toArray();
 
            $errors = array();
            foreach($main_errors as $key=>$value){
 
                if($key == "password"){
 
                    $main_errors[$key][0] = $value;
                }
                if($key == "email"){
 
                    $main_errors[$key][0] = $value;
                }
 
                return Response::json([
                    'success' => '0',
                    'message' => $value[0]
                ],200);
            }
 
        }else{
            
			#check if email exists into the table
            try{
                $check_email = DiaryUsers::where('email',$request->email)->first();
 
            }catch(\Exception $e){
                return Response::json(['success' => '0','message'=>$e->getMessage()],200);
            }
			
			#if email exists get the user password
            if(empty($check_email)){
                return Response::json(['success'=>'0','message'=>'Invalid Email id.'],200);
                exit;
            }else{
				
				#getting the password.
                try{
                    $user_details = DiaryUsers::select('id','password')->where('email',$request->email)->first();
                }catch(\Exception $e){
                    return Response::json(['success' => '0','message'=>$e->getMessage()],200);
                }
				
				#removing object class
                $user_details=json_decode(json_encode($user_details),true);
				
				#checking the db password with post password
				if(Hash::check($request->password,$user_details['password'])){

					DiaryLoginSessions::where('user_id', $user_details['id'])->update(['token_status' => 0]);
 
					#password matches, get the login_token from memeinsta_login_sessions
					/**Create API token**/
					$api_token = Str::random(60);
					 
					try{
						DiaryLoginSessions::insert([
									'user_id' => $user_details['id'],
									'api_token' => $api_token,
									'device_type' => $this->device_type,
									'device_token'=>$this->device_token,
									'header_api_token'=> $this->header_api_token,
									'token_status'=>1
									]);
					}catch(\Exception $e){
						return Response::json(['success' => '0','message'=>$e->getMessage()],200);
					}
 
					$data = array('api_token'=>$api_token,'user_id'=>(string)$user_details['id']);
					
					return Response::json(['success'=>'1','message'=>'Login Successful.','data'=>$data ],200);exit;
					
				}else{
					return Response::json(['success'=>'0','message'=>'Incorrect Password.'],200);exit;
				}
			}#check email ends
 
        }#validation else ends
		
	}#login fn ends here
	
	
}
